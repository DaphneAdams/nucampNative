import React, { Component } from 'react';
import { ScrollView } from 'react-native';
import { Card } from 'react-native-elements';



class Contact extends Component {
    static navigationOptions = {
        title: 'Contact Us'
    }
    render() {
        return (
            <ScrollView>

            </ScrollView>
        );
    }
}

export default Contact;